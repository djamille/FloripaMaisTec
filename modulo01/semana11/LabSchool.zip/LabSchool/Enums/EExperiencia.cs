﻿namespace LabSchool.Enums
{
    public enum EExperiencia
    {
        BACK_END,
        FRONT_END,
        FULL_STACK
    }
}
