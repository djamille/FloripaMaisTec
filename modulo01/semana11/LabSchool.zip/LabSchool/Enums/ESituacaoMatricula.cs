﻿namespace LabSchool.Enums
{
    public enum ESituacaoMatricula
    {
        ATENDIMENTO_PEDAGOGICO,
        ATIVO,
        IRREGULAR,
        INATIVO
    }
}
