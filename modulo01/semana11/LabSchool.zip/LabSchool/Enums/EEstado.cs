﻿namespace LabSchool.Enums
{
    public enum EEstado
    { 
        ATIVO,
        INATIVO
    }
}
