﻿namespace LabSchool.Enums
{
    public enum EFormacaoAcademica
    { 
        GRADUACAO_COMPLETA,
        GRADUACAO_INCOMPLETA,
        MESTRADO
    }
}
