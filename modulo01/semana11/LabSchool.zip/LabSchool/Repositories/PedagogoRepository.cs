﻿using LabSchool.Context;
using LabSchool.Models;
using LabSchool.Repositories.Interface;

namespace LabSchool.Repositories
{
    public class PedagogoRepository : IPedagogoRepository
    {
        private readonly LabSchoolContext _context;

        public PedagogoRepository(LabSchoolContext context)
        {
            _context = context;
        }


        public void Create(Pedagogo pedagogo)
        {
            _context.Pedagogos.Add(pedagogo);
            _context.SaveChanges();
        }


        public List<Pedagogo> List()
        {
            return _context.Pedagogos.ToList();
        }


        public Pedagogo? GetById(int cod)
        {
            return _context.Pedagogos.FirstOrDefault(x => x.Cod.Equals(cod));
        }


        public void Update(Pedagogo pedagogo)
        {
            _context.Pedagogos.Update(pedagogo);
            _context.SaveChanges();
        }


        public void Delete(int Cod)
        {
            var pedagogo = GetById(Cod);
            _context.Pedagogos.Remove(pedagogo);
            _context.SaveChanges();

        }
    }
}

