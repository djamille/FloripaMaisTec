﻿using LabSchool.Models;

namespace LabSchool.Repositories.Interface
{
    public interface IPedagogoRepository
    {
        void Create(Pedagogo pedagogo);
        List<Pedagogo> List();
        Pedagogo? GetById(int Cod);
        void Update(Pedagogo pedagogo);
        void Delete(int Cod);
    }
}
