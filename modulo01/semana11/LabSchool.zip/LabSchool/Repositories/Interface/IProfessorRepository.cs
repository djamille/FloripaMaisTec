﻿using LabSchool.Models;

namespace LabSchool.Repositories.Interface
{
    public interface IProfessorRepository
    {
        void Create(Professor professor);
        List<Professor> List();
        Professor? GetById(int Cod);
        void Update(Professor professor);
        void Delete(int Cod);
    }
}
