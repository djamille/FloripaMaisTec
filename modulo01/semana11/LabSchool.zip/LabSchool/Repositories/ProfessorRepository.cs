﻿using LabSchool.Context;
using LabSchool.Models;
using LabSchool.Repositories.Interface;

namespace LabSchool.Repositories
{
    public class ProfessorRepository : IProfessorRepository
    {
        private readonly LabSchoolContext _context;

        public ProfessorRepository(LabSchoolContext context)
        {
            _context = context;
        }


        public void Create(Professor professor)
        {
            _context.Professores.Add(professor);
            _context.SaveChanges();
        }


        public List<Professor> List()
        {
            return _context.Professores.ToList();
        }


        public Professor? GetById(int Cod)
        {
            return _context.Professores.FirstOrDefault(x => x.Cod.Equals(Cod));
        }


        public void Update(Professor professor)
        {
            _context.Professores.Update(professor);
            _context.SaveChanges();
        }


        public void Delete(int Cod)
        {
            var professor = GetById(Cod);
            _context.Professores.Remove(professor);
            _context.SaveChanges();

        }
    }
}
