﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace LabSchool.Models.Configurations
{
    public class AlunoConfiguration : IEntityTypeConfiguration<Aluno>
    {
        public void Configure(EntityTypeBuilder<Aluno> builder)
        {

            builder.HasKey(Key => Key.Cod);
            builder.Property(p => p.Nome).IsRequired().HasMaxLength(80);
            builder.Property(p => p.Telefone).IsRequired(false).HasMaxLength(14);
            builder.Property(p => p.DataNascimento).IsRequired();
            builder.Property(p => p.Situacao).IsRequired();
            builder.Property(p => p.Nota).IsRequired();
            builder.Property(p => p.QtdAtendimento).IsRequired().HasMaxLength(80);
            builder.Property(P => P.CPF).HasMaxLength(11);
            builder.HasIndex(P => P.CPF).IsUnique();


            builder.ToTable("Aluno");
        }
    }
}