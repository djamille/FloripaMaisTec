﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace LabSchool.Models.Configurations
{
    public class ProfessorConfiguration : IEntityTypeConfiguration<Professor>
    {
        public void Configure(EntityTypeBuilder<Professor> builder)
        {
            builder.HasKey(Key => Key.Cod);
            builder.Property(p => p.Nome).IsRequired().HasMaxLength(80);
            builder.Property(p => p.Telefone).IsRequired(false).HasMaxLength(14);
            builder.Property(p => p.DataNascimento).IsRequired();
            builder.Property(p => p.Formacao).IsRequired();
            builder.Property(p => p.Estado).IsRequired();
            builder.Property(p => p.Experiencia).IsRequired().HasMaxLength(80);
            builder.Property(P => P.CPF).HasMaxLength(11);
            builder.HasIndex(P => P.CPF).IsUnique();



            builder.ToTable("Professor");
        }
    }
}
