﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using LabSchool.Enums;

namespace LabSchool.Models
{
    public class Aluno : Pessoa
    {
        
        public ESituacaoMatricula Situacao { get; set; }
        public float Nota { get; set; }
        public int QtdAtendimento { get; set; }
        
        
        // virtual ICollection<Atendimento> Atendimentos { get; set; }
    }
}
