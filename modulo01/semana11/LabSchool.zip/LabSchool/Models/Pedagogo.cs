﻿namespace LabSchool.Models
{
    public class Pedagogo : Pessoa
    {
        public int QtdAtendimento { get; set; }


        //public virtual ICollection<Atendimento> Atendimentos { get; set; }
    }
}
