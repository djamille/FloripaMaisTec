﻿using LabSchool.Models;
using LabSchool.Models.Configurations;
using Microsoft.EntityFrameworkCore;

namespace LabSchool.Context
{
    public class LabSchoolContext : DbContext
    {

        public LabSchoolContext(DbContextOptions<LabSchoolContext> options) : base(options)
        {

        }


        public DbSet<Aluno> Alunos { get; set; }
        //public DbSet<Atendimento> Atendimentos { get; set; }
        public DbSet<Professor> Professores { get; set; }
        public DbSet<Pedagogo> Pedagogos { get; set; }
        
 

        /*
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=MILLE\\SQLEXPRESS;Database=djamille_labschoolbd;User ID=sa;Password=220202;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
        }

        */
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new AlunoConfiguration());
            modelBuilder.ApplyConfiguration(new ProfessorConfiguration());
            modelBuilder.ApplyConfiguration(new PedagogoConfiguration());
            
        }
    }
}
